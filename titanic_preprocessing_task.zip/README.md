
# Task 1: Data Cleaning & Preprocessing

## Dataset:
Titanic Dataset: https://www.kaggle.com/datasets/yasserh/titanic-dataset

## Steps:
1. Loaded dataset
2. Handled missing values
3. Label encoded categorical variables
4. Standardized numerical features
5. Removed outliers using IQR method

## Tools Used:
- Python
- Pandas, NumPy
- Seaborn, Matplotlib
- Scikit-learn

## Outcome:
Cleaned dataset ready for machine learning.
